

class Component():
	"""
	This class defines the actual blocks.
	"""
	_offset_translate_x = 0.0
	_offset_translate_y = 0.0
	_offset_translate_z = 0.0

	_offset_rotation_x = 0.0
	_offset_rotation_y = 0.0
	_offset_rotation_z = 0.0

	_offset_scale_x = 0.0
	_offset_scale_y = 0.0
	_offset_scale_z = 0.0

	object_source = ""
	group = ""
	base_source = ""
	line_type_block = False

	skin_name = ""
	skin_id = ""

	def __init__(self, translate:list, rotation:list, scale:list):
		self._offset_translate_x = translate[0]
		self._offset_translate_z = translate[1]
		self._offset_translate_y = translate[2]

		self._offset_rotation_x = rotation[0]
		self._offset_rotation_y = rotation[1]
		self._offset_rotation_z = rotation[2]

		self._offset_scale_x = scale[0]
		self._offset_scale_z = scale[1]
		self._offset_scale_y = scale[2]

