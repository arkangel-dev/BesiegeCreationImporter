class Block():
	"""
	This class will define each block from the BSG file... 
	It will contain a list of components which contain actual blocks and will be used to define blocks with multiple obj files...
	It will also contain the position, rotation and scale defined by the 
	"""
	
	components = []
	block_id = ""
	guid = ""
	name = ""
	code_name = ""
	flipped = ""

	_translate_x = 0.0
	_translate_y = 0.0
	_translate_z = 0.0

	_rotation_x = 0.0
	_rotation_y = 0.0
	_rotation_z = 0.0
	_rotation_w = 0.0

	_scale_x = 0.0
	_scale_y = 0.0
	_scale_z = 0.0

	def __init__(self, translation:list, rotation:list, scale:list):
		"""
		Constructor
		Parameters : __init__([x,y,z], [x,y,z,w], [x,y,z])
		"""
		self._translate_x = translation[0]
		self._translate_z = translation[1]
		self._translate_y = translation[2]

		self._rotation_x = rotation[0]
		self._rotation_y = rotation[1]
		self._rotation_z = rotation[2]
		self._rotation_w = rotation[3]

		self._scale_x = scale[0]
		self._scale_y = scale[1]
		self._scale_z = scale[2]

		self.components = []

	def getQuarternion(self):
		return [self._rotation_w, self._rotation_x, self._rotation_z, self._rotation_y]

	def getVectorPosition(self):
		return (self._translate_x, self._translate_y, self._translate_z)

	def getScale(self):
		return (self._scale_x, self._scale_z, self._scale_y)