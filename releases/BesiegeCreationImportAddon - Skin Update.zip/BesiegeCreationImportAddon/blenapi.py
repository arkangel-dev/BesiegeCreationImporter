import bpy
import os
import numpy as np
import math
import json
import xml.etree.ElementTree as ET

from mathutils import Euler, Quaternion, Vector, Matrix
from math import radians
from pathlib import Path
from .bsgreader import Reader
# from bsgreader import Reader

class BlenderAPI():

	# So we are defining 3 directories. One for the workshop skin directory, one 
	# for the skin folder in the game data skin directory and one to use as the backup
	# preferably the template vanilla skin from the game data directory. Note that the first 2
	# are pointing to a directory with multiple skins whereas the backup store is defining a single skin pack
	workshop_store = ""
	game_store = ""
	backup_store = ""

	status = ""
	status_description = []
	
	def __init__(self, ws_store, game_store, backup):
		self.status = 'OK'
		self.workshop_store = ws_store
		self.game_store = game_store
		self.backup_store = backup

	def ImportCreation(self, path, vanilla_skins=False, create_parent=False):
		ReaderInstance = Reader(path)
		block_list = ReaderInstance.ReadBlockData() # read the block data from the bsgreader class
		imported_list = []

		for block in block_list:
			for comp in block.components:
				print("Block {} >> Component {} ({})".format(block.block_id, comp.base_source, id(comp)))
		
		print("Importing {} blocks...".format(len(block_list)))
		for block in block_list:
			print("\tImporting {} components...".format(len(block.components)))
			for component in block.components:
				
				bpy.ops.object.select_all(action='DESELECT')

				model = self.FetchModel(component.base_source, component.skin_id, component.skin_name) if not vanilla_skins else self.FetchModel(component.base_source, 'Template', 'Template')
				bpy.ops.import_scene.obj(filepath=model[0])

				current_obj = bpy.context.selected_objects[0]
				for m in current_obj.data.materials:
					bpy.data.materials.remove(m)

				texture_name = component.skin_name if not vanilla_skins else 'Template'
				
				new_mat = self.GenerateMaterial(component, model[1], texture_name)
				current_obj.data.materials.append(new_mat)
				current_obj.active_material = new_mat

				# get the offset transform values from the skin model website
				preset_pos = [component._offset_translate_x, component._offset_translate_y, component._offset_translate_z]
				preset_rot = [component._offset_rotation_x, component._offset_rotation_y, component._offset_rotation_z]
				preset_sca = [component._offset_scale_x, component._offset_scale_z, component._offset_scale_y]
				current_obj.scale = (preset_sca)

				# special offset for propellers...
				# I'll think of a way to offset this in the json file...

				if (block.block_id in ['26','55']):
					preset_rot[1] += 23 if block.flipped != 'True' else -23

				# rotate according to the offset
				bpy.ops.transform.rotate(value=math.radians(preset_rot[0]), orient_axis='X', orient_type='LOCAL', orient_matrix_type='LOCAL')
				bpy.ops.transform.rotate(value=math.radians(preset_rot[1]), orient_axis='Y', orient_type='LOCAL', orient_matrix_type='LOCAL')
				bpy.ops.transform.rotate(value=math.radians(preset_rot[2]), orient_axis='Z', orient_type='LOCAL', orient_matrix_type='LOCAL')

				# translate according to the offset
				offset_x = (preset_pos[0])
				offset_y = (preset_pos[1])
				offset_z = (preset_pos[2])
				current_obj.location = Vector((offset_x, offset_y, offset_z))
				bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

				# scale
				current_obj.scale = block.getScale()

				# rotate
				current_obj.rotation_mode = 'QUATERNION'
				qtrans = Quaternion(block.getQuarternion())
				qtrans.invert()



				current_obj.rotation_quaternion  = qtrans

				current_obj.rotation_mode = 'XYZ'



				# translate according to the BSG file
				current_obj.location = Vector(block.getVectorPosition())
				imported_list.append(current_obj)

		# if create_parent:
		# 	self.CreateParent(imported_list)

	def CreateParent(self, obj_list):
		o = bpy.data.objects.new( "Parent", None )
		bpy.context.scene.objects.link(o)
		o.empty_draw_size = 5
		o.empty_draw_type = 'PLAIN_AXES'


	def FetchModel(self, block_name, skin_id, skin_name='Template'):

		dlist = 'null'
		if skin_name != 'Template':
			try:
				d = os.path.join(self.workshop_store, skin_id)
				dlist = [os.path.join(d, o) for o in os.listdir(d) if os.path.isdir(os.path.join(d,o))]
			except FileNotFoundError:
				pass
		model_dirs = [ # create a list of the directories to check

			os.path.join(self.workshop_store, skin_id, dlist[0], block_name),
			os.path.join(self.game_store, skin_name, block_name),
			os.path.join(self.backup_store, block_name)
		]

		for cdir in model_dirs:
			result_t = self.AttemptLoad(cdir, '.png')
			result_o = self.AttemptLoad(cdir, '.obj')
			if result_t and result_o: return [result_o, result_t]
			print('\t\t >> Cannot find in {}'.format(cdir))
		return ""

	def AttemptLoad(self, directory, extension):
		try:
			for f in os.listdir(directory):
				if f.endswith(extension):
					return os.path.join(directory, f)
		except FileNotFoundError as e:
			return False
		return False

	def GenerateMaterial(self, block, texture_path, texture_name):
		# Ok time to generate the material. So first We generate the material and then we return it... Its that simple
		# TODO : Add NodeGroup setup
		mat_name = block.base_source + texture_name + "Material"
		for m in bpy.data.materials:
			if mat_name == m.name:
				return m
		m = bpy.data.materials.new(name=mat_name) # create new material
		m.use_nodes = True # enable nodes
		nodes = m.node_tree.nodes
		nodes.clear() # get rid of the default nodes
		image_texture_node = nodes.new("ShaderNodeTexImage") # create nodes
		principled_bdsf_node = nodes.new("ShaderNodeBsdfPrincipled")
		output_node = nodes.new("ShaderNodeOutputMaterial")
		image_texture_node.location = (0, 0) # organise the nodes
		principled_bdsf_node.location = (400, 0)
		output_node.location = (800, 0)
		image_texture_node.image = bpy.data.images.load(texture_path) # load the image for the image texture node
		m.node_tree.links.new(principled_bdsf_node.inputs[0], image_texture_node.outputs[0])# link the ndoes
		m.node_tree.links.new(output_node.inputs[0], principled_bdsf_node.outputs[0])
		return m # return the newly generated material



	